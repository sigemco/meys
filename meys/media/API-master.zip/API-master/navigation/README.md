# Mess with User Interface
Use CSS to mess with the user interface of the Windy map. All the stuff is well under the `#windy` selector. Just make sure that the Windy logo remains unscaled, clickable, and with opacity 1.
