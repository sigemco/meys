# Boat tracker
As you can see, all stuff is handled by a well documented Leaflet API. Create your own backend, serving GeoJSON tracks with boats/planes/cars and use the code below if you would like.
