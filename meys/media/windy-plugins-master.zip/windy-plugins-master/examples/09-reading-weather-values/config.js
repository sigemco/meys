module.exports = {
    displayName: 'Interpolator',
    hook: 'menu',
};
