module.exports = {
    displayName: 'Boat tracker',
    hook: 'menu',
};
