![](https://www.windy.com/img/windy-plugins/example04.gif)
# Boat tracker
This plugin demonstrates how you can track your boats, planes, cars...

-----------------

See [Windy Plugins API](../../docs/WINDY_PLUGIN.md) to have better idea how plugin system works or [Windy API documentation](../../docs/WINDY_API.md)
