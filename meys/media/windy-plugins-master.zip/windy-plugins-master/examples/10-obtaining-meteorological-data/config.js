module.exports = {
    displayName: 'Loading backend data',
    hook: 'menu',
    className: 'plugin-lhpane plugin-mobile-fullscreen',
    exclusive: 'lhpane',
};
