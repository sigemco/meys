![](https://www.windy.com/img/windy-plugins/example03.gif)
# Window on the right side
Use right side window for apps that that are fine with narrow window.

This plugin also demonstrates using GeoJSON on a map.

-----------------

See [Windy Plugins API](../../docs/WINDY_PLUGIN.md) to have better idea how plugin system works or [Windy API documentation](../../docs/WINDY_API.md)
