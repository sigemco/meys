![](https://www.windy.com/img/windy-plugins/example01.gif)
# Weather picker
Picker emits messages `pickerOpened`, `pickerClosed` and `pickerMoved`. Open your console, to see it in action.

-----------------

See [Windy Plugins API](../../docs/WINDY_PLUGIN.md) to have better idea how plugin system works or [Windy API documentation](../../docs/WINDY_API.md)
