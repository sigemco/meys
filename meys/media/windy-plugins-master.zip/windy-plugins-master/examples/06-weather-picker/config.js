module.exports = {
    displayName: 'Picker example',
    hook: 'menu',
};
